# Dashboard upload examples

18 unmodified RGB PNGs from the cached CIFAR-10 test split: the first three examples of each of bird, cat, deer, dog, frog, and horse in test-set order. Selection did not use model predictions.

Each PNG is 32 by 32 pixels and preserves the original uint8 RGB pixel values exactly. Upload the individual PNGs to the dashboard. The filename and labels.csv provide the dataset label, not the model prediction.

For each upload, record the predicted animal, its displayed score, and any app error. Check that repeated predictions for the same image are stable. Also click Predict with no image: the dashboard should request an upload.

These examples check the upload and prediction flow. Eighteen predictions do not provide a reliable overall accuracy estimate. A wrong prediction can occur even when the dashboard is connected correctly. Formal model accuracy uses the complete held-out animal test set.

CIFAR-10 source: https://www.cs.toronto.edu/~kriz/cifar.html
